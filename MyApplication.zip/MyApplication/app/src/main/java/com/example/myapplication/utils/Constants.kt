package com.example.myapplication.utils

const val BASE_URL: String = "https://jsonplaceholder.typicode.com"